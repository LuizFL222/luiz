
package br.senac.es;

import javax.swing.JOptionPane;


public class Quest4 {
    public static void main(String[] args) {
        int[] a = new int[10];
        a[0] = 1;
        a[1] = 7
        
        
        
    }
}
