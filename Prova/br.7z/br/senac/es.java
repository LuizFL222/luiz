package br.senac;

public class es {

    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        int aux = a;
        a = b;
        b = aux;

        System.out.println("A = " + a);
        System.out.println("B = " + b);

    }

}
